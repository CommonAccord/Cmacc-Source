_Subject=<span class="definedterm">Research Subject</span>
 
Certificate.Who.Subject.Self.0.sec=Person who is the subject of the {_Data} (could be observations, samples, test results, self assessments, etc) and who is presumptively the person that gives or withholds consent:

Note=2. The role of SubjectAgent is inappropriate in this context I think

Note=HazardJ - let me try renaming the Subject Agent, what do you think? 

_Subject_Agent=<span class="definedterm">Research Subject Substitute Decision Maker</span>

Certificate.Who.Subject.Agent.0.sec=Person who, if the {_Subject} is incapable of giving consent, acts in the interests of the {_Subject} and provides or withholds consent:

_Consent_Recipient=<span class="definedterm">Study Sponsor</span>
 
_Investigator=<span class="definedterm">Local Investigator</span>

Certificate.Who.Investigator.Self.0.sec=The study team members that have access to the health record, the data subject & de-identifies data but are not providing or responsible for treatment or health services):

_Data_Controller=<span class="definedterm">Research Data Controller</span>

Certificate.Who.DataController.Self.0.sec=The entity accountable for the research data - probably the study sponsor:

_Data_Custodian=<span class="definedterm">Research Data Custodian</span>

Certificate.Who.DataCustodian.Self.0.sec=The entity responsible to the {_Data_Controller} - often a study sponsor will use a CRO - clinical research organization - to do the actual work:

_Data_Access_Custodian=<span class="definedterm">Research Data Access Custodian</span>

_Data_Recipient=<span class="definedterm">Research Data Recipient</span>


=[GH/KantaraInitiative/DG-BSC/HRC/Demo/Roles/0.md]

=[zF/00/Consent/Outline/0.md]
