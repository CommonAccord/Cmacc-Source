Certificate.Who.Investigator.Self.0.sec=Person directly supervising the {_Study} for which {_this_Consent} is obtained:

=[GH/KantaraInitiative/DG-BSC/HRC/Demo/Consent/v01-JW.md]
  
Note=Also added defined terms for Investigator and Investigator_Agent and Study.